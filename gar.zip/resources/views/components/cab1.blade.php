<h5 class="text-primary py-2 mb-2" style='border-bottom: 1px solid #ccc; margin-bottom: 0px;font-family: roboto;'>
    {{$texto}}
</h5>