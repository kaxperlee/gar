
<div>
    <h3>{{$title}}</h3>
    {{$slot}}
</div>