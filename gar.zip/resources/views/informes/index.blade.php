@extends('layouts.main')

@section('sidebar')
   
    <x-sb-codigos />
       
@endsection

@section('main')
<x-cab1 texto="Informes" />
<x-cab2 texto="Informes recientes" />
@endsection