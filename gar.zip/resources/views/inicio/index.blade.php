@extends('layouts.main')

@section('sidebar')
   
    
       
@endsection

@section('main')
<x-cab1 texto="Inicio" />
<x-cab2 texto="Actividad reciente" />

@endsection