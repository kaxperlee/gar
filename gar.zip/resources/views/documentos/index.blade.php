@extends('layouts.main')

@section('sidebar')
   
    <x-sb-codigos />
       
@endsection

@section('main')
<x-cab1 texto="Documentos" />
<x-cab2 texto="Documentos recientes" />
@endsection