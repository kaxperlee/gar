<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ControlsController extends Controller
{
    //
}
