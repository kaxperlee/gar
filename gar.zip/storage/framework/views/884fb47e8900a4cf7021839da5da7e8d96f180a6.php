<a href="/">
    <img src="<?php echo e(asset('images/logoros.png')); ?>" class="rounded float-start" alt="Grupo Asesor Ros">
</a>
<?php /**PATH D:\WEB\LARAVEL\gar\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>