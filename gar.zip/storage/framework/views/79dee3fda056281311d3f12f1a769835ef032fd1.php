<h5 class="text-dark ps-1 mt-2" style='padding:0px;margin:0px;font-family: roboto;'>
    <?php echo e($texto); ?>

</h5>
<?php /**PATH D:\WEB\LARAVEL\gar\resources\views/components/cab4.blade.php ENDPATH**/ ?>