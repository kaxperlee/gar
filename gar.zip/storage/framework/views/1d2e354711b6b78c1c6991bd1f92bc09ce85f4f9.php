<?php $__env->startSection('sidebar'); ?>

    <?php if (isset($component)) { $__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SbCodigos::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sb-codigos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SbCodigos::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c)): ?>
<?php $component = $__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c; ?>
<?php unset($__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab1','data' => ['texto' => 'Seguimiento']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Seguimiento']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab2','data' => ['texto' => 'Clientes recientes '.e($tabulador['mon']).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Clientes recientes '.e($tabulador['mon']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link <?php echo e($tabulador['exp']); ?>" id="exp-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">Delito</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link <?php echo e($tabulador['act']); ?>" id="actividad-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">Actividades de riesgo</button>
    </li>
    <li class="nav-item " role="presentation">
        <button class="nav-link <?php echo e($tabulador['acl']); ?>" id="actual-tab" data-bs-toggle="tab" data-bs-target="#actual-tab-pane" type="button" role="tab" aria-controls="actual-tab-pane" aria-selected="false">Controles actuales</button>
    </li>
    <li class="nav-item " role="presentation">
        <button class="nav-link <?php echo e($tabulador['mon']); ?>" id="control-tab" data-bs-toggle="tab" data-bs-target="#contact-tab-pane" type="button" role="tab" aria-controls="contact-tab-pane" aria-selected="false">Controles propuestos</button>
    </li>
    <li class="nav-item " role="presentation">
        <button class="nav-link <?php echo e($tabulador['fil']); ?>" id="ficheros-tab" data-bs-toggle="tab" data-bs-target="#ficheros-tab-pane" type="button" role="tab" aria-controls="ficheros-tab-pane" aria-selected="false">Ficheros</button>
    </li>
</ul>
<div class="px-3">
    <div class="container-fluid">
        <div class="tab-content mt-3" id="myTabContent">
            <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="exp-tab" tabindex="0">
                <div class="d-flex mb-3" style='width:100%;background-color:white'>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab3','data' => ['texto' => ''.e($seguimiento->Delito->Epigrafe).'/'.e($seguimiento->Delito->Delito).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => ''.e($seguimiento->Delito->Epigrafe).'/'.e($seguimiento->Delito->Delito).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <a type="button" href="<?php echo e(route('seguimiento.index')); ?>" class="btn btn-primary btn-sm me-2"><i class="fa-solid fa-trash"></i> Delete</a>
                    <a type="button" href="#" class="btn btn-primary btn-sm me-2"><i class="fa-solid fa-box-archive"></i> Archivar</a>
                    <a type="button" href="<?php echo e(route('seguimiento.index')); ?>" class="btn btn-primary btn-sm me-2"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                </div>
                <div class="row">
                    <div class="col-4 my-2">
                        <label for="idCodigo">id: </label><br>
                        <input  class="form-control" type="text" name="idCodigo" value="<?php echo e($seguimiento->id); ?>" readonly>
                    </div>
                    <div class="col-4 my-2">
                        <label for="epigrafe">Epigrafe</label><br>
                        <input  class="form-control" type="text" name="epigrafe" value="<?php echo e($seguimiento->Delito->Epigrafe); ?>" readonly>
                    </div>
                    <div class="col-4 my-2">
                        <label for="Codigo">Codigo</label><br>
                        <input class="form-control" widt="100%" type="text" name="Codigo"  value=<?php echo e($seguimiento->Delito->Codigo); ?> readonly>
                    </div>
                    <div class="col-12 my-2">
                        <label for="caracter">Delito</label><br>
                        <input class="form-control" type="text" name="fecha" value="<?php echo e($seguimiento->Delito->Delito); ?>" readonly>
                    </div>
                    <div class="col-12 my-2">
                        <label for="descripcion">Descripción:</label><br>
                        <textarea style='resize: none;' name="descripcion" class="form-control" id="descripcion" rows="2"  readonly><?php echo e($seguimiento->Delito->Descripcion); ?></textarea>
                    </div>
                    <div class="col-4 my-2">
                        <label for="fecha">Fecha (dd/mm/aaaa)</label><br>
                        <input class="form-control" type="date" name="fecha" value="<?php echo e($seguimiento->Fecha); ?>" readonly>
                    </div>
                    <div class="col-4 my-2">
                        <label for="manejo_id">Manejo riesgo:</label><br>
                        <input name="manejo_id" type="text" value="<?php echo e($seguimiento->Manejo->Nombre); ?>" class="form-control" id="manejo_id"  readonly>
                    </div>
                    <div class="col-4 my-2">
                        <label for="calificacion_id">Calificación nivel riesgo:</label><br>
                        <input class="form-control" type="text" name="calificacion_id" id="calificacion_id" value="<?php echo e($seguimiento->Calificacion->Nombre); ?>" readonly >
                    </div>
                    <div class="col-12 my-2">
                        <label for="Observaciones">Descripción:</label><br>
                        <textarea style='resize: none;' name="Observaciones" class="form-control" id="Observaciones" rows="2"  readonly><?php echo e($seguimiento->Observaciones); ?></textarea>
                    </div>
                    <div class="d-flex flex-row-reverse mt-3">
                        <a type="button" href="<?php echo e(route('seguimiento.destroy', $seguimiento)); ?>" class="btn btn-primary btn-sm me-2"><i class="fa-solid fa-trash"></i> Delete</a>
                        <a type="button" href="#" class="btn btn-primary btn-sm me-2"><i class="fa-solid fa-box-archive"></i> Archivar</a>
                        <a type="button" href="<?php echo e(route('seguimiento.edit', $seguimiento)); ?>" class="btn btn-primary btn-sm me-2"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                    </div>

                </div>
            </div>
            <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="actividad-tab" tabindex="0">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab3','data' => ['texto' => ''.e($seguimiento->Delito->Epigrafe).'/'.e($seguimiento->Delito->Delito).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => ''.e($seguimiento->Delito->Epigrafe).'/'.e($seguimiento->Delito->Delito).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab4','data' => ['texto' => 'Actividades de riesgo']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab4'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Actividades de riesgo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <div class="px-3 mb-5">
                    <div class="container-fluid">
                        <div class="row">
                            <?php $__currentLoopData = $seguimiento->Riesgos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riesgo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 mt-3">
                                <div class="card" >
                                    <div class="card-body">
                                    <p class="card-text"><?php echo e($riesgo->Nombre); ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="actual-tab-pane" role="tabpanel" aria-labelledby="control-tab" tabindex="0">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab3','data' => ['texto' => ''.e($seguimiento->Delito->Epigrafe).'/'.e($seguimiento->Delito->Delito).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => ''.e($seguimiento->Delito->Epigrafe).'/'.e($seguimiento->Delito->Delito).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab4','data' => ['texto' => 'Controles actuales']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab4'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Controles actuales']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <div class="px-3 mb-5">
                    <div class="container-fluid">
                        <table class='table'>
                            <tr>
                                <th>id: </th>
                                <th>Nombre</th>
                                <th>hh</th>
                            </tr>
                            <tr>
                                <td>a</td>
                                <td>b</td>
                                <td>c</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="contact-tab-pane" role="tabpanel" aria-labelledby="control-tab" tabindex="0">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab3','data' => ['texto' => ''.e($seguimiento->Delito->Epigrafe).'/'.e($seguimiento->Delito->Delito).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => ''.e($seguimiento->Delito->Epigrafe).'/'.e($seguimiento->Delito->Delito).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab4','data' => ['texto' => 'Políticas de actuación']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab4'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Políticas de actuación']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <div class="px-3 mb-5">
                    <div class="container-fluid">
                        <div class="row">
                            <?php $__currentLoopData = $seguimiento->Controls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $control): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 mt-3">
                                <div class="card" >
                                    <div class="card-body">
                                    <p class="card-text"><?php echo e($control->Nombre); ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="ficheros-tab-pane" role="tabpanel" aria-labelledby="ficheros-tab" tabindex="0">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab3','data' => ['texto' => ''.e($seguimiento->Codigo).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => ''.e($seguimiento->Codigo).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab4','data' => ['texto' => 'Ficheros']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab4'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Ficheros']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <div class="p-1">
                    <div class="col-12 my-4">
                        <div class="h-100 p-5 bg-light border rounded-3">
                        <h5 class="">Ficheros</h5>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form method="POST" action="<?php echo e(route('files.destroy',$file)); ?>">
                            <div class="input-group mb-3">
                                <a href="<?php echo e(route('files.download',['id' => $file->id])); ?>" class="btn btn-primary">Ver <?php echo e($file->id); ?></a>
                                <input type="text" class="form-control" value="<?php echo e($file->Nombre); ?>" readonly aria-describedby="button-addon2">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <input type="hidden" name="id" value="<?php echo e($seguimiento->id); ?>">
                                <button class="btn btn-danger" type="submit"><i class="fa-solid fa-circle-xmark"></i></button>
                            </div>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <h5 class="mt-5">Añadir fichero</h5>
                            <form method="POST" enctype="multipart/form-data" id="upload-file" action="<?php echo e(route('incidencias.fileform')); ?>">
                                <div class="container">
                                    <div class="row">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($seguimiento->id); ?>">
                                        <div class="col-12 my-2">
                                            <input class="form-control" type="file" name="file" id="file" placeholder="Selecciona un fichero">
                                        </div>
                                        <div class="col-2 my-2">
                                            <label for="formFile" class="form-label"> </label>
                                            <button class="btn btn-primary" type="submit">Enviar</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<div class="container pb-5"></div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\LARAVEL\gar\resources\views/seguimiento/show.blade.php ENDPATH**/ ?>