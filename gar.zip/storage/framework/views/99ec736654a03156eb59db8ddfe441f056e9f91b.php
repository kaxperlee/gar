<h5 class="text-dark pb-2 ps-1" style='font-family: roboto;'>
    <?php echo e($texto); ?>

</h5><?php /**PATH C:\WEB\LARAVEL\gar\resources\views/components/cab2.blade.php ENDPATH**/ ?>