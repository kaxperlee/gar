<?php $__env->startSection('sidebar'); ?>

    <?php if (isset($component)) { $__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SbCodigos::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sb-codigos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SbCodigos::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c)): ?>
<?php $component = $__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c; ?>
<?php unset($__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab1','data' => ['texto' => 'Riesgos']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Riesgos']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab2','data' => ['texto' => 'Clientes recientes']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Clientes recientes']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<div class="container">
  <div class="row">
    <div class="col-3 my-2">
        <label for="idCodigo">idCodigo</label><br>
        <input  class="form-control" type="text" name="idCodigo" value="<?php echo e($incidencia->id); ?>" readonly>
    </div>
    <div class="col-3 my-2">
        <label for="epigrafe">Epigrafe</label><br>
        <input  class="form-control" type="text" name="epigrafe" value="<?php echo e($incidencia->idCodigo); ?>" readonly>
    </div>
    <div class="col-3 my-2">
        <label for="fecha">Fecha (dd/mm/aaaa)</label><br>
        <input class="form-control" type="date" name="fecha" value="<?php echo e($incidencia->Fecha); ?>" readonly>
    </div>
    <div class="col-3 my-2">
        <label for="caracter">Caracter</label><br>
        <input class="form-control" type="text" name="fecha" value="<?php echo e($incidencia->Caracter); ?>" readonly>
    </div>
    <div class="col-12 my-2">
        <label for="Codigo">Codigo</label><br>
        <input class="form-control" widt="100%" type="text" name="Codigo"  value="<?php echo e($incidencia->Codigo); ?>" readonly>
    </div>
    <div class="col-6 my-2">
        <label for="descripcion">Descripción:</label><br>
        <textarea style='resize: none;' name="descripcion" class="form-control" id="descripcion" rows="3"  readonly><?php echo e($incidencia->Descripcion); ?></textarea>

    </div>
    <div class="col-6 my-2">
        <label for="riesgoa">Riesgo afectado / Conducta delictiva:</label><br>
        <textarea style='resize: none;' name="riesgoa" class="form-control" id="riesgoa" rows="3" readonly><?php echo e($incidencia->Descripcion); ?></textarea>
    </div>

    <div class="col-6 my-2">
        <label for="informara">Informar a:</label><br>
        <input class="form-control" type="text" name="informara"  value="<?php echo e($incidencia->InformarA); ?>" readonly >
    </div>
    <div class="col-6 my-2">
        <label for="remitente">Remitente:</label><br>
        <input class="form-control" type="text" name="remitente"  value="<?php echo e($incidencia->Remitente); ?>" readonly >
    </div>

    <div class="col-3 my-2">
        <label for="canal">Canal:</label><br>
        <input class="form-control" type="text" name="remitente"  value="<?php echo e($incidencia->Canal); ?>" readonly >

    </div>
    <div class="col-3 my-2">
        <label for="fechat">Fecha de tramitación:</label><br>
        <input class="form-control" type="date" name="fechat"  value="<?php echo e($incidencia->FechaT); ?>" readonly >
    </div>
    <div class="col-3 my-2">
        <label for="propuesta">Propuesta:</label><br>
        <input class="form-control" type="text" name="propuesta"  value="<?php echo e($incidencia->Propuesta); ?>" readonly >
    </div>
    <div class="col-3 my-2">
        <label for="nivelrp">Nivel de riesgo penal:</label><br>
        <input class="form-control" type="text" name="nivelrp"  value="<?php echo e($incidencia->NivelRP); ?>" readonly >
    </div>
    <div class="col-6 my-2">
        <label for="comunicara">Comunicar a autoridades:</label><br>
        <textarea style='resize: none;' name="comunicara" class="form-control" id="comunicara" rows="3" readonly><?php echo e($incidencia->ComunicarA); ?></textarea>

    </div>
    <div class="col-6 my-2">
        <label for="autoria">Autoría:</label><br>
        <textarea style='resize: none;' name="autoria" class="form-control" id="autoria" rows="3" readonly><?php echo e($incidencia->Autoria); ?></textarea>
    </div>
    <div class="col-6 my-2">
        <label for="observaciones">Observaciones:</label><br>
        <textarea style='resize: none;' name="observaciones" class="form-control" id="observaciones" rows="3" readonly><?php echo e($incidencia->Observaciones); ?></textarea>

    </div>
    <div class="col-6 my-2">
        <label for="propuestas">Propuestas:</label><br>
        <textarea style='resize: none;' name="propuestas" class="form-control" id="propuestas" rows="3" readonly><?php echo e($incidencia->Propuestas); ?></textarea>
    </div>
    <div class="col-12 my-2">
        <label for="formFile" class="form-label">Ficheros: </label>
        <input class="form-control" name="formFile" type="file" id="formFile">
        <div id="formFile" class="form-text">Selecciona un fichero.</div>
    </div>


    <div class="col my-2">
        <button class="btn btn-primary" type="submit">Guardar</button>
    </div>
  </div>
</div>

<div>
    <form method="POST" enctype="multipart/form-data" id="upload-file" action="<?php echo e(route('incidencias.fileform')); ?>">
        <?php echo csrf_field(); ?>
        <input type="file" name="file" id="file" placeholder="Selecciona un fichero">
        <input type="id"  name="id" value="<?php echo e($incidencia->id); ?>">
        <button type="submit">Enviar</button>
    </form>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\LARAVEL\gar\resources\views/incidencias/show.blade.php ENDPATH**/ ?>