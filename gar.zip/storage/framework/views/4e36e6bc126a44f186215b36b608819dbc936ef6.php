<?php $__env->startSection('sidebar'); ?>

    <?php if (isset($component)) { $__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SbCodigos::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sb-codigos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SbCodigos::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c)): ?>
<?php $component = $__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c; ?>
<?php unset($__componentOriginal2a8c106df04d7eaf875dbaf21dcf98d75da96c7c); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab1','data' => ['texto' => 'Riesgos']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Riesgos']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab2','data' => ['texto' => 'Alta control']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Alta control']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<?php echo Form::model($delito, ['route' => ['seguimiento.store',$delito]]); ?>

<div class="container">
  <div class="row">
    <div class="col-6 my-2">
        <?php echo Form::label('Epigrafe','Epigrafe:'); ?>

        <?php echo Form::text('Epigrafe',$delito->Epigrafe,['class'=>'form-control','readonly']); ?>

    </div>
    <div class="col-6 my-2">
        <?php echo Form::label('Codigo','Código:'); ?>

        <?php echo Form::text('Codigo',$delito->Codigo,['class'=>'form-control','readonly']); ?>

    </div>

    <div class="col-12 my-2">
        <?php echo Form::label('Delito','Delito:'); ?>

        <?php echo Form::text('Delito',$delito->Delito,['class'=>'form-control','readonly']); ?>

    </div>
    <div class="col-12 my-2">
        <?php echo Form::label('Descripcion','Descripción:'); ?>

        <?php echo Form::textarea('Descripcion',$delito->Descripcion,['class'=>'form-control','rows' => '4','readonly']); ?>

    </div>
    <div class="col-4 my-2">
        <?php echo Form::label('Fecha','Fecha:'); ?>

        <?php echo Form::date('Fecha',null,['class'=>'form-control']); ?>

    </div>
    <div class="col-4 my-2">
        <?php echo Form::label('manejo_id','Manejo riesgo:'); ?>

        <?php echo Form::select('manejo_id',$manejos,NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-4 my-2">
        <?php echo Form::label('calificacion_id','Calificacion nivel riesgo:'); ?>

        <?php echo Form::select('calificacion_id',$calificacions,NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-12 my-2">
        <?php echo Form::label('Observaciones','Observaciones:'); ?>

        <?php echo Form::textarea('Observaciones',null,['class'=>'form-control','rows' => '2']); ?>

    </div>
        <?php echo Form::hidden('id',$delito->id,NULL); ?>

    <div class="col my-2">
        <button class="btn btn-primary" type="submit">Alta en Seguimiento</button>
    </div>
  </div>
</div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\LARAVEL\gar\resources\views/seguimiento/create.blade.php ENDPATH**/ ?>