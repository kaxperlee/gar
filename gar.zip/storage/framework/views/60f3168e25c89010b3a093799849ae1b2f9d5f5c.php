<h5 class="text-primary py-2 mb-2" style='border-bottom: 1px solid #ccc; margin-bottom: 0px;font-family: roboto;'>
    <?php echo e($texto); ?>

</h5><?php /**PATH D:\WEB\LARAVEL\gar\resources\views/components/cab1.blade.php ENDPATH**/ ?>