<div>
    <div class="mb-4">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab1','data' => ['texto' => 'Nueva incidencia']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Nueva incidencia']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <form action="<?php echo e(route('incidencias.search')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="">
                    <span><strong>Código delito:</strong> </br></span>
                    <input class="form-control mt-2" type="text" name="riesgo">
                </label>
            </div>
            <input type="submit" name="mysubmit" value="Buscar"  class="btn btn-primary btn-sm" />
            <input type="reset" name="mysubmit" value="Reset"  class="btn btn-primary btn-sm" />
        </form>
    </div>


</div>
<?php /**PATH D:\WEB\LARAVEL\gar\resources\views/components/sb-codigos.blade.php ENDPATH**/ ?>