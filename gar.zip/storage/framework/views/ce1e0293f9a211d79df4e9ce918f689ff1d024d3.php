<h5 class="text-dark ps-1 me-auto" style='padding:0px;margin:0px;font-family: roboto;'>
    <?php echo e($texto); ?>

</h5>
<?php /**PATH D:\WEB\LARAVEL\gar\resources\views/components/cab3.blade.php ENDPATH**/ ?>