<div class="row">
    <div class="col-3 my-2">
        <?php echo Form::label('id','id:'); ?>

        <?php echo Form::text('id',NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-3 my-2">
        <?php echo Form::label('epigrafe','Epigrafe:'); ?>

        <?php echo Form::text('Epigrafe',NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-3 my-2">
        <?php echo Form::label('fecha','Fecha:'); ?>

        <?php echo Form::date('Fecha',NULL,['class'=>'form-control']); ?>

    </div>

    <div class="col-3 my-2">
        <?php echo Form::label('Caracter','Caracter:'); ?>

        <?php echo Form::select('Caracter',$caracter,NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-12 my-2">
        <?php echo Form::label('codigo','Codigo:'); ?>

        <?php echo Form::text('Codigo',NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-6 my-2">
        <?php echo Form::label('Descripcion','Descripcion:'); ?>

        <?php echo Form::textarea('Descripcion',NULL,['class'=>'form-control','rows'=>'3', 'style'=>'resize: none']); ?>

    </div>
    <div class="col-6 my-2">
        <?php echo Form::label('RiesgoA','Riesgo afectado / Conducta delictiva:'); ?>

        <?php echo Form::textarea('RiesgoA',NULL,['class'=>'form-control','rows'=>'3', 'style'=>'resize: none']); ?>

    </div>
    <div class="col-6 my-2">
        <?php echo Form::label('InformarA','Informar a:'); ?>

        <?php echo Form::text('InformarA',NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-6 my-2">
        <?php echo Form::label('Remitente','Remitente:'); ?>

        <?php echo Form::text('Remitente',NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-3 my-2">
        <?php echo Form::label('Canal','Canal:'); ?>

        <?php echo Form::select('Canal',$canal,NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-3 my-2">
        <?php echo Form::label('FechaT','Fecha de tramitación:'); ?>

        <?php echo Form::date('FechaT',NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-3 my-2">
        <?php echo Form::label('Propuesta','Propuesta:'); ?>

        <?php echo Form::text('Propuesta',NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-3 my-2">
        <?php echo Form::label('NivelRP','Nivel de riesgo penal:'); ?>

        <?php echo Form::text('NivelRP',NULL,['class'=>'form-control']); ?>

    </div>
    <div class="col-6 my-2">
        <?php echo Form::label('ComunicarA','Comunicar a autoridades:'); ?>

        <?php echo Form::textarea('ComunicarA',NULL,['class'=>'form-control','rows'=>'3', 'style'=>'resize: none']); ?>

    </div>
    <div class="col-6 my-2">
        <?php echo Form::label('Autoria','Autoría:'); ?>

        <?php echo Form::textarea('Autoria',NULL,['class'=>'form-control','rows'=>'3', 'style'=>'resize: none']); ?>

    </div>
    <div class="col-6 my-2">
        <?php echo Form::label('Observaciones','Observaciones:'); ?>

        <?php echo Form::textarea('Observaciones',NULL,['class'=>'form-control','rows'=>'3', 'style'=>'resize: none']); ?>

    </div>
    <div class="col-6 my-2">
        <?php echo Form::label('Propuestas','Propuestas:'); ?>

        <?php echo Form::textarea('Propuestas',NULL,['class'=>'form-control','rows'=>'3', 'style'=>'resize: none']); ?>

    </div>

</div>
<?php /**PATH D:\WEB\LARAVEL\gar\resources\views/incidencias/layouts/form.blade.php ENDPATH**/ ?>