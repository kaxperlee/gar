<?php $__env->startSection('sidebar'); ?>

    <?php if (isset($component)) { $__componentOriginal11139430e5ee15e70c1eeba736fb5da2a94c64f8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SbSeguimiento::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sb-seguimiento'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SbSeguimiento::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11139430e5ee15e70c1eeba736fb5da2a94c64f8)): ?>
<?php $component = $__componentOriginal11139430e5ee15e70c1eeba736fb5da2a94c64f8; ?>
<?php unset($__componentOriginal11139430e5ee15e70c1eeba736fb5da2a94c64f8); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab1','data' => ['texto' => 'Delito']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Delito']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab2','data' => ['texto' => 'Bùsqueda ()']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Bùsqueda ()']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<table class="table table-hover" width="100%">
    <tr>
        <th>Epigrafe</th>
        <th>Código</th>
        <th>Delito</th>
        <th>Nº Incidencias</th>
    </tr>
<?php $__currentLoopData = $delitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($delito->Epigrafe); ?></td>
        <td><?php echo e($delito->Codigo); ?></td>
        <td><a href="<?php echo e(route('incidencias.create', $delito->id)); ?>"><?php echo e($delito->Delito); ?></a></td>
        <td><?php if($delito->Incidencias): ?><?php echo e($delito->Incidencias->count()); ?> <?php endif; ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\LARAVEL\gar\resources\views/incidencias/search.blade.php ENDPATH**/ ?>