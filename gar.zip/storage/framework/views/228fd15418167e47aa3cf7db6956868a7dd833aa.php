<div>
    <div class="mb-4">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab1','data' => ['texto' => 'Nueva incidencia']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Nueva incidencia']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <form action="<?php echo e(route('codigos.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="">
                    <span><strong>Código riesgo:</strong> </br></span> 
                    <input class="form-control mt-2" type="text" name="riesgo">
                </label>
            </div>
            <input type="submit" name="mysubmit" value="Buscar"  class="btn btn-primary btn-sm" />
            <input type="reset" name="mysubmit" value="Reset"  class="btn btn-primary btn-sm" />
        </form>
    </div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cab1','data' => ['texto' => 'Riesgos']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cab1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['texto' => 'Riesgos']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <ul>
    <?php $__currentLoopData = $codigos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li style='list-style-type: none; margin-left:-30px; padding-bottom:4px;'>
        <a style="text-decoration-line: none"  href="<?php echo e(route('codigos.grupo', $codigo->idCodigo)); ?>"><?php echo e($codigo->idCodigo); ?>. <?php echo e($codigo->idCodigo2); ?></a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH C:\WEB\LARAVEL\gar\resources\views/components/sb-codigos.blade.php ENDPATH**/ ?>